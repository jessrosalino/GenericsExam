module GenericsExam {
}