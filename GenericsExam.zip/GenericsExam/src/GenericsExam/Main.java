package GenericsExam;

import java.util.*;
public class Main {
 public static void main(String args[])
 {

     ArrayList<Integer> arreglo = new ArrayList<>();
     arreglo.add(1);
     arreglo.add(2);
     arreglo.add(3);
     arreglo.add(4);


 }
 }
     