package GenericsExam;

public interface GenericsExam <T> {

	T product(int index1, int index2);
	T maxvalue (T collection);
	T minvalue (T collection);
	T sum (int index1, int index2);
}


