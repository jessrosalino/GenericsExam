package GenericsExam;

import java.util.ArrayList;
public class MixMax <T extends Number> implements GenericsExam<Object> {

	
	public static void main(String args[])
 {

     ArrayList<Integer> arreglo = new ArrayList<>();
     arreglo.add(1);
     arreglo.add(2);
     arreglo.add(3);
     arreglo.add(4);

     int minimo = arreglo.get(0);
     int maximo = arreglo.get(0);

 
     int n = arreglo.size();

     for (int i = 1; i < n; i++) {
         if (arreglo.get(i) > maximo) {
             maximo = arreglo.get(i);
         }
     }

     for (int i = 1; i < n; i++) {
         if (arreglo.get(i) < minimo) {
             minimo = arreglo.get(i);
         }
     }

     System.out.println("The maximum value is : " + maximo);
     System.out.println("The minimum value is : " + minimo);
 }

	@Override
	public Object product(int index1, int index2) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object maxvalue(Object collection) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object minvalue(Object collection) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object sum(int index1, int index2) {
		// TODO Auto-generated method stub
		return null;
	}
}